# Analise-Brasileirao2013-2023
 Análise do Brasileirão Série A com Python e Power BI
